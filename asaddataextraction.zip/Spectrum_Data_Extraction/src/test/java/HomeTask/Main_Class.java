package HomeTask;



import java.awt.AWTException;
import java.io.IOException;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;



public class Main_Class {

	
	WebDriver driver=new ChromeDriver();
	Object_Class object=new Object_Class(driver);
	
	@BeforeMethod
	public void Before_method() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vitsl\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		
		
		//PropertyConfigurator.configure("log4j.properties");
		}
	@Test(priority = 0)
	public void Mobile() throws InterruptedException, IOException, AWTException {
		
		object.clicklaptop("https://www.spectrum.com/mobile/products/phones","D:\\Excel_files_URl\\Mobiles.xlsx",2);
		
		
	}
	@Test(priority = 1)
	public void Tablets() throws InterruptedException, IOException, AWTException {
		
		object.clicklaptop("https://www.spectrum.com/mobile/products/tablets","D:\\Excel_files_URl\\Tablets.xlsx",1);
		
		
	}

	@Test(priority = 2)
	public void SmartWatches() throws InterruptedException, IOException, AWTException {

		object.clicklaptop("https://www.spectrum.com/mobile/products/smartwatches","D:\\Excel_files_URl\\SmartWatches.xlsx",1);


	}

	@Test(priority = 3)
	public void Accesories() throws InterruptedException, IOException, AWTException {

		object.clicklaptop("https://www.spectrum.com/mobile/products/accessories","D:\\Excel_files_URl\\Accessories.xlsx",18);


	}

	@Test(priority = 4)
	public void All_Accerioes() throws InterruptedException, IOException, AWTException {

		object.clicklaptop("https://www.spectrum.com/mobile/products/accessories","D:\\Excel_Files\\Accessories.xlsx",18);


	}

}


