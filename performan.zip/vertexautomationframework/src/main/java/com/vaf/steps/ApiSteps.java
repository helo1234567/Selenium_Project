package com.vaf.steps;

import com.vaf.api.APIManager;
import com.vaf.utils.Assertions;
import com.vaf.utils.ExcelUtil;
import com.vaf.utils.LogUtil;
import cucumber.api.java.en.And;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.Test;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.vaf.utils.LogUtil.logInfo;

public class ApiSteps {

    APIManager mgrr = new APIManager();

    ExcelUtil mg=new ExcelUtil();

    public static Response postresponse;

    private String previousResonse = "{}";
    @Test
    @And("User sends {string} request for key {string} for endpoint {string}")
    public void Post_Req(String method,String key,String endpoint) throws IOException {

        ArrayList<String> data = (ArrayList<String>) mg.getData(key);

        int counter = 0;

        for (String json : data) {
            if (counter == 0) {
                counter++;
                continue;
            }
            if (!mgrr.ValidJson(json)) {

                logInfo("Invalid JSON"+"  :"+json);
                System.out.println("Invalid JSON: " + json);

            }
        }
        String body = APIManager.autoFillResponseValues(previousResonse, data.get(1));
        System.out.println("Response for body Request"+body);
        String header = APIManager.autoFillResponseValues(previousResonse, data.get(2));
        System.out.println("Response for header Request"+header);
        String query = APIManager.autoFillResponseValues(previousResonse, data.get(3));
        System.out.println("Response for query Request"+query);
        String query1 = APIManager.autoFillResponseValues(previousResonse, data.get(4));
        System.out.println("Response for quer1 Request"+query1);
        postresponse = mgrr.PostRequest(body , header, query,endpoint,method);
        previousResonse = postresponse.body().asString();
        System.out.println("Response for Post Request"+previousResonse);
    }

    @Then("validate that response will be same as stored in {string}")
    public void validateResponse(String filePath) throws IOException {
        // Retrieve stored response from JSON file
        JSONParser jsonParser = new JSONParser();
        JSONObject storedResponse = null;

        try (FileReader reader = new FileReader(ExcelUtil.getFileFromResourceFolder(filePath))) {
            Object obj = jsonParser.parse(reader);
            storedResponse = (JSONObject) obj;
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Compare response with stored response
        JSONObject responseJson = null;

        try {
            responseJson = (JSONObject) jsonParser.parse(previousResonse);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //Assertions.assertTrue(responseJson != null && responseJson.equals(storedResponse),"Response Matched or Not",null);
        if (responseJson != null && responseJson.equals(storedResponse)) {

            logInfo("Response matches the stored response.");
            System.out.println("Response matches the stored response.");
            // Test case pass code here
        } else {
            logInfo("Response does not match the stored response.");
            System.out.println("Response does not match the stored response.");
            // Test case fail code here
        }
    }




    @Test
    @And("user send multiple {string} requests for Keys {string} for endpoint {string}")
    public void sendMultipless(String method, String compoundKey, String endpoint) throws IOException {
        String sheetName = compoundKey.split("[.]")[0];
        String sheetName1 = compoundKey.split("[.]")[1];
        String datakey = compoundKey.split("[.]")[2];
        ArrayList<String> data = (ArrayList<String>) mg.getData(sheetName + "." + datakey);
        int rowCount = (int) ExcelUtil.getRowCount(sheetName1);

        for (int i = 0; i < rowCount; i++) {
            ArrayList<String> modifiedData = new ArrayList<>();

            for (String json : data) {
                Pattern pattern = Pattern.compile("#\\{([^}]+)\\}"); // Regular expression pattern to match #{placeholder}
                Matcher matcher = pattern.matcher(json);

                while (matcher.find()) {
                    String placeholder = matcher.group(1); // Extracting the placeholder without #{}
                    List<String> values = ExcelUtil.valuesFor(sheetName1 + "." + placeholder);
                    if (!values.isEmpty() && i < values.size()) {
                        String replacement = values.get(i); // Get the value corresponding to the current index
                        json = json.replaceAll("#\\{" + placeholder + "\\}", replacement);
                    }
                }

                modifiedData.add(json);
            }

            postresponse = mgrr.PostRequest(modifiedData.get(1), modifiedData.get(2), modifiedData.get(3), endpoint, method);
            previousResonse = postresponse.body().asString();
            System.out.println("Response for Post Request: " + previousResonse);
        }
    }
}
