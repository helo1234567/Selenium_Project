package com.vaf.steps;

import com.vaf.api.APIManager;
import com.vaf.utils.ConfigUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.vaf.utils.ExcelUtil;
import com.vaf.utils.Excel_Api;
import cucumber.api.java.en.And;
import io.cucumber.java.en.Then;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;
import org.testng.annotations.Test;

import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ApiSteps {
    Excel_Api excelApi = new Excel_Api();
    APIManager mgr = new APIManager();
    ExcelUtil mg = new ExcelUtil();
    //newapiclass mg = new newapiclass();
    private Response postresponse;
    private Response putresponse;
    private Response getresponse;
    private String previousResonse = "{}";

    @Test
    @And("User sends {string} request for key {string} for endpoint {string}")
    public void Post_Req(String method, String key, String endpoint) throws IOException {

        ArrayList<String> data = (ArrayList<String>) mg.getData(key);

        for (String json : data) {
            if (!mgr.ValidJson(json)) {
                // Handle invalid JSON
                // For example, you can log an error or throw an exception
                System.out.println("Invalid JSONNNNNNNNNNNNNN: " + json);
                continue; // Skip to the next iteration
            }
        }
        String body = APIManager.autoFillResponseValues(previousResonse, data.get(1));
        String header = APIManager.autoFillResponseValues(previousResonse, data.get(2));
        String query = APIManager.autoFillResponseValues(previousResonse, data.get(3));
        String query1 = APIManager.autoFillResponseValues(previousResonse, data.get(4));
        postresponse = mgr.PostRequest(body, header, query, endpoint, method);
        previousResonse = postresponse.body().asString();
        System.out.println("Response for Post Request" + previousResonse);
    }

    @Then("validate that response will be same as stored in {string}")
    public void validateResponse(String filePath) throws IOException {
        // Retrieve stored response from JSON file
        JSONParser jsonParser = new JSONParser();
        JSONObject storedResponse = null;

        try (FileReader reader = new FileReader(ExcelUtil.getFileFromResourceFolder(filePath))) {
            Object obj = jsonParser.parse(reader);
            storedResponse = (JSONObject) obj;
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Compare response with stored response
        JSONObject responseJson = null;

        try {
            responseJson = (JSONObject) jsonParser.parse(previousResonse);
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (responseJson != null && responseJson.equals(storedResponse)) {
            System.out.println("Response matches the stored response.");
            // Test case pass code here
        } else {
            System.out.println("Response does not match the stored response.");
            // Test case fail code here
        }
    }


    @Test
    @And("User sends multiple {string} requests for keys {string} for endpoint {string}")
    public void sendMultiplePostRequest(String requestType, String keys, String endpoint) throws IOException {
        String[] keyParts = keys.split(",");
        String sheetName = keyParts[0];
        List<String> dataKeys = Arrays.asList(keyParts).subList(1, keyParts.length);

        for (String dataKey : dataKeys) {
            String fullDataKey = sheetName + "." + dataKey;
            List<List<String>> requestData = Collections.singletonList(ExcelUtil.getData(fullDataKey));

            for (List<String> request : requestData) {
                String body = APIManager.autoFillResponseValues(previousResonse, request.get(1));
                String header = APIManager.autoFillResponseValues(previousResonse, request.get(2));
                String query = APIManager.autoFillResponseValues(previousResonse, request.get(3));
                String query1 = APIManager.autoFillResponseValues(previousResonse, request.get(4));
                postresponse = mgr.PostRequest(body, header, query, endpoint, requestType);
                previousResonse = postresponse.body().asString();
                System.out.println("Response for Post Request" + previousResonse);
            }
        }
    }

    @Test
    @And("User send multiple {string} requests for keys {string} for endpoint {string}")
    public void sendMultiplePostRequests(String method, String compoundKey, String endpoint) throws IOException {
        String sheetName = compoundKey.split("[.]")[0];
        String datakey = compoundKey.split("[.]")[1];


        int rowCount = (int) ExcelUtil.getRowCount(sheetName);
        for (int row = 1; row <= rowCount; row++) {
            String currentKey = ExcelUtil.getCellData(sheetName, row, 0);
            if (currentKey.equalsIgnoreCase(datakey)) {
                List<String> requestData = ExcelUtil.getRowData(sheetName, row);
                String body = APIManager.autoFillResponseValues(previousResonse, requestData.get(1));
                String header = APIManager.autoFillResponseValues(previousResonse, requestData.get(2));
                String query = APIManager.autoFillResponseValues(previousResonse, requestData.get(3));

                postresponse = mgr.PostRequest(body, header, query, endpoint, method);
                previousResonse = postresponse.body().asString();
                System.out.println("Response for Post Request: " + previousResonse);
            }
        }
    }

    @Test
    @And("user send multiples {string} requests for Keys {string} for endpoint {string}")
    public void sendMultiple(String method, String compoundKey, String endpoint) throws IOException {
        String sheetName = compoundKey.split("[.]")[0];
        String sheetName1 = compoundKey.split("[.]")[1];
        String datakey = compoundKey.split("[.]")[2];
        ArrayList<String> data = (ArrayList<String>) mg.getData(sheetName + "." + datakey);
        List<String> Allvalues = ExcelUtil.valuesFor(sheetName1 + "." + datakey);


        for (String value : Allvalues) {
            ArrayList<String> modifiedData = new ArrayList<>();

            for (String json : data) {
                json = json.replaceAll("#\\{[^}]+\\}", value);
                modifiedData.add(json);
            }
            postresponse = mgr.PostRequest(modifiedData.get(1), modifiedData.get(2), modifiedData.get(3), endpoint, method);
            previousResonse = postresponse.body().asString();
            System.out.println("Response for Post Request: " + previousResonse);
        }
    }
}





























//    @Test
//    @And("User send post request to Add place in {string}")
//    public void Post_Request(String key) throws IOException {
//
//        ArrayList<String> data = excelApi.getData(key);
//        postresponse=mgr.PostRequest(data.get(1),data.get(3),data.get(5),data.get(6));
//
//    }
//
//    @Test
//    @And("Put New Address {string} in {string} in {string}")
//    public void Put_Request(String key1,String key2,String key) throws IOException {
//        ArrayList<String> data = excelApi.getData(key);
//        putresponse=mgr.PostRequest(data.get(1),data.get(3),data.get(5),data.get(6));
//
//    }
//
//    @Test
//    @And("Set the {string} in {string} on Index <{int}>")
//    public void Set_ID_In_Excel(String key1,String key2,Integer key3) throws IOException {
//        updateExcelData("testdata", key2,key3, postresponse.jsonPath().get(key1).toString());
//
//    }
//
//    @Test
//    @And("Verify that status code must be <{int}>")
//    public void Status_code(Integer key) throws IOException {
//        int statusCode = postresponse.getStatusCode();
//        Assert.assertEquals(key, statusCode);
//
//
//    }
//
//    @Then("Validate that the {string} must be {string}")
//    public void validatePlaceId(String key, String expectedPlaceId) throws IOException {
//        JsonPath jsonPath = postresponse.jsonPath();
//        String actualPlaceId = jsonPath.get(key);
//        System.out.println(actualPlaceId);
//        //Assert.assertEquals(expectedPlaceId, actualPlaceId);
//
//    }
//
////    @And("User send get request to retrieve place details by sending new {string} in {string}")
////    public void sendGetRequest(String key1,String key2) throws IOException {
////        ArrayList<String> data = excelApi.getData(key2);
////        JsonPath jsonPath = postresponse.jsonPath();
////        String placeId = jsonPath.get(key1);
////        getresponse = mgr.GetRequest(data.get(7),key1,data.get(3),data.get(6));
////    }
//
//    private void updateExcelData(String sheetName, String testCaseName, int columnIndex, String value) throws IOException {
//        FileInputStream fis = new FileInputStream("C:\\Users\\DELL\\Documents\\Asad\\demodata.xlsx");
//        Workbook workbook = new XSSFWorkbook(fis);
//        Sheet sheet = workbook.getSheet(sheetName);
//
//        // Find the row for the given test case name
//        for (Row row : sheet) {
//            Cell cell = row.getCell(0); // Assuming the test case names are in the first column (index 0)
//            if (cell.getStringCellValue().equalsIgnoreCase(testCaseName)) {
//                Cell valueCell = row.createCell(columnIndex);
//                valueCell.setCellValue(value);
//                break;
//            }
//        }
//
//        // Write changes back to the Excel file
//        FileOutputStream fos = new FileOutputStream("C:\\Users\\DELL\\Documents\\Asad\\demodata.xlsx");
//        workbook.write(fos);
//        fos.close();
//        workbook.close();
//    }
//}
