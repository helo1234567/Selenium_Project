package com.vaf.utils;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.util.*;
import java.io.File;
import java.io.FileInputStream;
import java.net.URISyntaxException;
import java.net.URL;

import com.vaf.web.UIManager.LocatorType;
public class ExcelUtil {

    private static String LOCATOR_FILE_PATH = "locators_datasheet.xlsx";
    private static String MOCK_FILE_PATH = "mock_datashee.xls";

    private static String API_FILE_PATH = "demodata1.xlsx";
    public static Map<String, Object> getLocatorFor(String compoundKey) {
        String sheetName = compoundKey.split("[.]")[0];
        String key = compoundKey.split("[.]")[1];

        try {
            File file;
            try {
                file = getFileFromURL(LOCATOR_FILE_PATH);
            } catch (Exception e) {
                System.out.println("File not found: " + e.getMessage());
                return null;
            }

            FileInputStream fis = new FileInputStream(file);
            Workbook wb;
            if (LOCATOR_FILE_PATH.toLowerCase().endsWith(".xlsx")) {
                wb = new XSSFWorkbook(fis);
            } else {
                wb = new HSSFWorkbook(fis);
            }
            Sheet sheet = wb.getSheet(sheetName);

            Iterator<Row> itr = sheet.iterator();

            while (itr.hasNext()) {
                Row row = itr.next();
                Iterator<Cell> cellIterator = row.cellIterator();

                String locatorName = "";
                String locatorValue = "";
                LocatorType locatorType = null;
                String Textvalue="";

                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();

                    if (cell.getColumnIndex() == 0) {
                        locatorName = cell.getStringCellValue();
                    } else if (cell.getColumnIndex() == 1) {
                        locatorValue = cell.getStringCellValue();
                    } else if (cell.getColumnIndex() == 2) {
                        String type = cell.getStringCellValue().toLowerCase();
                        if ("xpath".equals(type)) {
                            locatorType = LocatorType.xpath;
                        } else if ("cssselector".equals(type)) {
                            locatorType = LocatorType.cssSelector;
                        } else if ("cssid".equals(type)) {
                            locatorType = LocatorType.cssId;
                        } else if ("cssclass".equals(type)) {
                            locatorType = LocatorType.cssClass;
                        } else {
                            throw new IllegalArgumentException("Invalid locator type: " + type);
                        }
                    }
                    else if (cell.getColumnIndex() == 3) {
                        if (cell.getCellType() == CellType.STRING) {
                            Textvalue = cell.getStringCellValue();
                        } else if (cell.getCellType() == CellType.NUMERIC) {
                            double numericValue = cell.getNumericCellValue();
                            Textvalue = String.valueOf(numericValue);
                        }
                    }
                }

                if (locatorName.equals(key)) {
                    Map<String, Object> locatorMap = new HashMap<String, Object>();
                    locatorMap.put("name", locatorName);
                    locatorMap.put("value", locatorValue);
                    locatorMap.put("type", locatorType);
                    locatorMap.put("Text", Textvalue);
                    return locatorMap;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static List<String> valuesFor(String compoundKey) {
        List<String> values = new ArrayList<>();

        String sheetName = compoundKey.split("[.]")[0];
        String key = compoundKey.split("[.]")[1];

        try {
            File file;
            try {
                file = getFileFromURL(MOCK_FILE_PATH);
            } catch (Exception e) {
                System.out.println("File not found: " + e.getMessage());
                return null;
            }

            FileInputStream fis = new FileInputStream(file);
            Workbook wb;
            if (MOCK_FILE_PATH.toLowerCase().endsWith(".xlsx")) {
                wb = new XSSFWorkbook(fis);
            } else {
                wb = new HSSFWorkbook(fis);
            }
            Sheet sheet = wb.getSheet(sheetName);
            Iterator<Row> itr = sheet.iterator();    // iterating over excel file

            Integer rowIndex = 0;
            Integer foundIndex = -1;
            while (itr.hasNext()) {
                Row row = itr.next();
                Iterator<Cell> cellIterator = row.cellIterator();   // iterating over each column

                Integer cellIndex = 0;

                if (foundIndex < 0) {
                    while (cellIterator.hasNext()) {
                        Cell cell = cellIterator.next();
                        if (cell.getStringCellValue().equals(key)) {
                            foundIndex = cellIndex;
                            break;
                        }

                        cellIndex++;
                    }
                }
                else {
                    Cell cellVal = CellUtil.getCell(row, foundIndex);
                    if (cellVal.getCellType() == CellType.STRING) {
                        values.add(cellVal.getStringCellValue());
                    } else if (cellVal.getCellType() == CellType.NUMERIC) {
                        double numericValue = cellVal.getNumericCellValue();
                        values.add(String.valueOf(numericValue));
                    }
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        values.removeIf(entries -> entries.isEmpty());

        return values;
    }

    public static List<String> getData(String compoundKey) throws IOException {
        String sheetName = compoundKey.split("[.]")[0];
        String key = compoundKey.split("[.]")[1];

        List<String> values = new ArrayList<>();

        try {
            File file;
            try {
                file = getFileFromURL(API_FILE_PATH);
            } catch (Exception e) {
                System.out.println("File not found: " + e.getMessage());
                return null;
            }

            FileInputStream fis = new FileInputStream(file);
            Workbook wb;
            if (API_FILE_PATH.toLowerCase().endsWith(".xlsx")) {
                wb = new XSSFWorkbook(fis);
            } else {
                wb = new HSSFWorkbook(fis);
            }
            Sheet sheet = wb.getSheet(sheetName);
            Iterator<Row> itr = sheet.iterator();    // iterating over excel file

            while (itr.hasNext()) {
                Row row = itr.next();
                Cell cell = row.getCell(0);
                if (cell != null && cell.getCellType() == CellType.STRING) {
                    String cellValue = cell.getStringCellValue();
                    if (cellValue.equals(key)) {
                        Iterator<Cell> cellIterator = row.iterator();

                        while (cellIterator.hasNext()) {
                            Cell dataCell = cellIterator.next();
                            if (dataCell.getCellType() == CellType.STRING) {
                                values.add(dataCell.getStringCellValue());
                            }
                            else if (dataCell.getCellType() == CellType.NUMERIC) {
                                double numericValue = dataCell.getNumericCellValue();
                                values.add(String.valueOf(numericValue));
                            }
                            else if (dataCell.getCellType() == CellType.BLANK) {
                                values.add(""); // Treat empty cell as an empty string
                            }
                        }
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return values;
    }


    public static Object getRowCount(String sheetName) {
        File file;
        try {
            file = getFileFromURL(API_FILE_PATH);
        } catch (Exception e) {
            System.out.println("File not found: " + e.getMessage());
            return null;
        }

        try {
            FileInputStream fis = new FileInputStream(file);
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheet(sheetName);
            int rowCount = sheet.getLastRowNum();
            workbook.close();
            fis.close();
            return rowCount;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static String getCellData(String sheetName,int rowNumber, int columnNumber) {

        File file;
        try {
            file = getFileFromURL(API_FILE_PATH);
        } catch (Exception e) {
            System.out.println("File not found: " + e.getMessage());
            return null;
        }


        try {
            FileInputStream fis = new FileInputStream(file);
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheet(sheetName);
            Row row = sheet.getRow(rowNumber);
            Cell cell = row.getCell(columnNumber);
            String cellData = cell.toString();
            workbook.close();
            fis.close();
            return cellData;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
    public static List<String> getRowData(String sheetName, int rowNumber) {
        File file;
        try {
            file = getFileFromURL(API_FILE_PATH);
        } catch (Exception e) {
            System.out.println("File not found: " + e.getMessage());
            return null;
        }
        try {
            FileInputStream fis = new FileInputStream(file);
            Workbook workbook = WorkbookFactory.create(fis);
            Sheet sheet = workbook.getSheet(sheetName);
            Row row = sheet.getRow(rowNumber);
            List<String> rowData = new ArrayList<>();

            for (Cell cell : row) {
                String cellValue = "";

                if (cell.getCellType() == CellType.STRING) {
                    cellValue = cell.getStringCellValue();
                } else if (cell.getCellType() == CellType.BLANK) {
                    cellValue = "";
                }

                rowData.add(cellValue);
            }

            workbook.close();
            fis.close();
            return rowData;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Collections.emptyList();
    }


    private static File getFileFromURL(String filePath) throws URISyntaxException {
        URL url = new ExcelUtil().getClass().getClassLoader().getResource(filePath);
        File file = null;
        file = new File(url.toURI());
        return file;
    }}

