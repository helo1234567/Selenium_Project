package com.vaf.steps

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class GatlingExample extends Simulation {

  val httpProtocol = http
    .baseUrl("https://www.amazon.com") // Replace with your target URL

  val scn = scenario("Example Scenario")
    .exec(http("Example Request")
      .get("/gp/goldbox?ref_=nav_cs_gb")) // Replace with your request details

  setUp(
    scn.inject(
      rampUsers(50).during(5.seconds) // Ramp up to 50 users over 5 seconds
    )
  ).protocols(httpProtocol)
}
