package com.spec

package com.spec

import io.cucumber.scala.{EN, ScalaDsl}
import io.gatling.core.Predef._
import io.gatling.http.Predef._

class GatlingSteps extends ScalaDsl with EN {

  val httpProtocol = http
    .baseUrl("https://www.amazon.com")

  Given("""^the user is on the homepage$""") { () =>
    // Perform necessary setup actions, if any
  }

  When("""^the user sends a GET request to "([^"]*)"$""") { (path: String) =>
    exec(http("Example Request")
      .get(path))
  }

  Then("""^the response status code should be (\d+)$""") { (statusCode: Int) =>
    exec(http("Verify Status Code")
      .check(status.is(statusCode)))
  }

  // Additional step definitions, if any

  val scn = scenario("Gatling Example").exec(
    // Define the sequence of steps/actions to be executed in the simulation
    Given("the user is on the homepage"),
    When("""the user sends a GET request to "/gp/goldbox?ref_=nav_cs_gb""""),
    Then("the response status code should be 200")
  )

  setUp(
    scn.inject(
      rampUsers(50).during(5.seconds)
    )
  ).protocols(httpProtocol)

}
