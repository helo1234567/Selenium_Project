package com.vaf.web;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import com.deque.axe.AXE;
import com.vaf.utils.ConfigUtil;
import com.vaf.utils.LogUtil;
import io.qameta.allure.Attachment;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.vaf.enumerations.BrowserType;
import com.paulhammant.ngwebdriver.NgWebDriver;
import org.testng.Assert;


public class UIManager {
	public enum LocatorType {
		xpath,
		cssSelector,
		cssId,
		cssClass,
	}

	private Duration timeOut = Duration.ofMillis(40000);
	public static WebDriver driver;
	Browser browser=new Browser();
	private NgWebDriver ngWebDriver = null;

	public static String currentBrowser = "";

	private static  final URL scripturl=UIManager.class.getResource("/axe.min.js");

	public UIManager(){
		UIManager.currentBrowser = ConfigUtil.CONFIG_GET_STRING("Browser").toUpperCase();

		String browserType = ConfigUtil.CONFIG_GET_STRING("Browser").toUpperCase();
		boolean headless = Boolean.parseBoolean(ConfigUtil.CONFIG_GET_STRING("headless"));
		this.driver = browser.getInstance(BrowserType.valueOf(browserType),headless);

	}

	public UIManager(BrowserType browserType, boolean headless) {
		String webBrowser = browserType.toString();
		this.driver = browser.getInstance(BrowserType.valueOf(webBrowser), headless);
	}

	// Session Methods
	public void startSession(String url) { driver.get(url); }

	public void endSession() { driver.quit(); }

	public void waitImplicit(Integer duration) { driver.manage().timeouts().implicitlyWait(Duration.ofMillis(duration)); }

	public void waitForAngular() { ngWebDriver.waitForAngularRequestsToFinish(); }

	public WebDriverWait explicitWait() { return new WebDriverWait(driver, timeOut); }

	public void waitUntilVisible(String locator) { this.waitUntilVisible(locator, LocatorType.xpath); }

	public void waitUntilVisible(String locator, LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);
		this.waitUntilVisible(we);
	}

	public void waitUntilVisible(WebElement element) {
		explicitWait().until(ExpectedConditions.visibilityOf(element));
	}

	// WebElement
	public WebElement elementBy(LocatorType type, String locator) {
		switch(type) {
			case cssSelector:
				return driver.findElement(By.cssSelector(locator));
			case cssId:
				return driver.findElement(By.id(locator));
			case cssClass:
				return driver.findElement(By.className(locator));
			default:
				return driver.findElement(By.xpath(locator));
		}
	}


	// Action: Hover and Click

	public void hoverAndClick(String hoverLocator, String clickLocator) { this.hoverAndClick(hoverLocator, clickLocator, LocatorType.xpath); }

	public void hoverAndClick(String hoverLocator, String clickLocator, LocatorType locatorType) {

		WebElement hoverElement = this.elementBy(locatorType, hoverLocator);

//		this.hoverAndClick(hoverElement, clickElement);

		// Instantiate Action Class
		Actions actions = new Actions(driver);

		// Mouse hover menuOption 'Music'
		actions.moveToElement(hoverElement).perform();

		this.waitUntilVisible(clickLocator);

		WebElement clickElement = this.elementBy(locatorType, clickLocator);

		// Mouse hover menuOption 'Rock'
		actions.moveToElement(clickElement).perform();

		// Click on the element
		clickElement.click();
	}


	public void hoverAndClick(String hoverLocator, String clickLocator, LocatorType locatorType,LocatorType locatorType1) {

		WebElement hoverElement = this.elementBy(locatorType, hoverLocator);

//		this.hoverAndClick(hoverElement, clickElement);

		// Instantiate Action Class
		Actions actions = new Actions(driver);

		// Mouse hover menuOption 'Music'
		actions.moveToElement(hoverElement).perform();

		this.waitUntilVisible(clickLocator);

		WebElement clickElement = this.elementBy(locatorType1, clickLocator);

		// Mouse hover menuOption 'Rock'
		actions.moveToElement(clickElement).perform();

		// Click on the element
		clickElement.click();
	}

	public void hover(String hoverLocator) { this.hover(hoverLocator,LocatorType.xpath); }

	public void hover(String hoverLocator, LocatorType locatorType) {

		WebElement hoverElement = this.elementBy(locatorType, hoverLocator);

//		this.hoverAndClick(hoverElement, clickElement);

		// Instantiate Action Class
		Actions actions = new Actions(driver);
		this.waitUntilVisible(hoverLocator);
		// Mouse hover menuOption 'Music'
		actions.moveToElement(hoverElement).perform();


	}

	public void hoverAndClick(WebElement hoverElement,WebElement clickElement) {
		// Instantiate Action Class
		Actions actions = new Actions(driver);

		// Mouse hover menuOption 'Music'
		actions.moveToElement(hoverElement).perform();

		this.waitUntilVisible(clickElement);

		// Mouse hover menuOption 'Rock'
		actions.moveToElement(clickElement).perform();

		// Click on the element
		clickElement.click();
	}

	public void hover(WebElement hoverElement) {
		// Instantiate Action Class
		Actions actions = new Actions(driver);

		// Mouse hover menuOption 'Music'
		actions.moveToElement(hoverElement).perform();

	}


	// Actions: Clickable
	public void click(String locator) { this.click(locator, LocatorType.xpath); }

	public void click(String locator, LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);
		this.waitUntilVisible(we);
		this.click(we);
	}

	public void clearText(String locator, LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);
		this.waitUntilVisible(we);
		we.click();
		we.clear();
	}

	public void accessibility() {
		JSONObject jsonresponse = new AXE.Builder(driver, scripturl).analyze();
		JSONArray violations = jsonresponse.getJSONArray("violations");

		if (violations.length() == 0) {
			System.out.println("No accessibility issues found.");
		} else {
			int crucialCount = 0;
			int seriousCount = 0;
			int moderateCount = 0;
			int minorCount = 0;

			AXE.writeResults("accessibility", jsonresponse);

			System.out.println("Accessibility Issues:\n");

			for (int i = 0; i < violations.length(); i++) {
				JSONObject violation = violations.getJSONObject(i);
				String impact = violation.getString("impact");
				String description = violation.getString("description");
				JSONArray nodes = violation.getJSONArray("nodes");

				System.out.println("Issue " + (i + 1) + ": " + description + " [Impact: " + impact + "]");
				System.out.println("  Details: " + violation.getString("help"));

				// Print each affected element
				System.out.println("  Elements Affected:");
				for (int j = 0; j < nodes.length(); j++) {
					JSONObject node = nodes.getJSONObject(j);
					System.out.println("    " + node.getString("html"));
				}

				// Print fix suggestions if available
				if (violation.has("helpUrl")) {
					System.out.println("  Fix any of the following:");
					System.out.println("    " + violation.getString("helpUrl"));
				}

				if (impact.equalsIgnoreCase("critical")) {
					crucialCount++;
				} else if (impact.equalsIgnoreCase("serious")) {
					seriousCount++;
				} else if (impact.equalsIgnoreCase("moderate")) {
					moderateCount++;
				} else if (impact.equalsIgnoreCase("minor")) {
					minorCount++;
				}

				System.out.println(); // Adding an empty line between issues for better readability
			}

			// Print the Accessibility Issue Summary
			System.out.println("Accessibility Issue Summary:");
			System.out.println("Critical issues: " + crucialCount);
			System.out.println("Serious issues: " + seriousCount);
			System.out.println("Moderate issues: " + moderateCount);
			System.out.println("Minor issues: " + minorCount);


			// Assertions
			Assert.assertTrue(crucialCount == 0, "Crucial issues found: " + crucialCount);
			Assert.assertTrue(seriousCount == 0, "Serious issues found: " + seriousCount);
			Assert.assertTrue(moderateCount == 0, "Moderate issues found: " + moderateCount);
		}
	}


	public void click(WebElement element) {
		explicitWait().until(ExpectedConditions.elementToBeClickable(element));
		element.click();
	}

	public void doubleClick(String locator, LocatorType locatorType) {
		Actions actions = new Actions(driver);
		WebElement we = this.elementBy(locatorType, locator);
		this.waitUntilVisible(we);
		actions.doubleClick(we).build().perform();
	}

	public void pressEnter(String locator, LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);
		this.waitUntilVisible(we);
		we.sendKeys(Keys.ENTER);
	}

	public void fillTextField(String locator, String text) throws InterruptedException { this.fillTextField(locator, text, LocatorType.xpath);}

	public void fillTextField(String locator, String text, LocatorType locatorType) throws InterruptedException {
		WebElement we = this.elementBy(locatorType, locator);
		this.fillTextField(we, text);
	}


	public void fillTextField(String locator, Keys key, LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);

		this.fillTextField(we, key);
	}

	public void fillTextField(WebElement element, String text) throws InterruptedException {

		this.waitUntilVisible(element);
		element.sendKeys(text);
	}

	public void fillTextField(WebElement element, Keys key) {
		element.sendKeys(key);
	}

	// Dropdown

	public void selectDropdownOption(String dropdownLocator, String clickLocator) { this.selectDropdownOption(dropdownLocator, clickLocator,LocatorType.xpath); }

	public void selectDropdownOption(String dropdownLocator, String clickLocator,LocatorType locatorType) {
		WebElement selectDropdown = this.elementBy(locatorType, dropdownLocator);
		WebElement selectElement = this.elementBy(locatorType, clickLocator);
		String  interactValue=selectElement.getText();
		this.selectDropdownOption(selectDropdown, selectElement, interactValue);

	}

	public void selectDropdownOption(String dropdownLocator, String clickLocator,LocatorType locatorType,LocatorType locatorType1) {
		WebElement selectDropdown = this.elementBy(locatorType, dropdownLocator);
		WebElement selectElement = this.elementBy(locatorType1, clickLocator);
		String  interactValue=selectElement.getText();
		this.selectDropdownOption(selectDropdown, selectElement, interactValue);

	}


	public void selectDropdownOption(WebElement dropdownElement, WebElement clickElement,String dropdownvalue) {
		explicitWait().until(ExpectedConditions.visibilityOf(dropdownElement));

		Select select = new Select(dropdownElement);

		explicitWait().until(ExpectedConditions.visibilityOf(clickElement));

		select.selectByVisibleText(dropdownvalue);
	}

	// Browser Navigation

	public void scroll(WebElement element) {
		this.scroll(element, true);
	}

	public void scroll(WebElement element, boolean scrollIntoView) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")", element);
	}

	public void scroll(String element) {
		this.scroll(element, true);
	}

	public void scroll(String element,LocatorType locatorType, boolean scrollIntoView) {
		WebElement scrollLocator = this.elementBy(locatorType, element);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")", scrollLocator);
	}

	public void scroll(String element, boolean scrollIntoView) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")", element);
	}

	public void scroll_and_Click(String element,String element2,LocatorType locatorType) {
		this.scroll_and_Click(element,element2,locatorType,false);
	}

	public void scroll_and_Click(String element,String element2,LocatorType locatorType,LocatorType locatorType1) {
		this.scroll_and_Click(element,element2,locatorType,locatorType1,false);
	}

	public void scroll_and_Click(String element,String element2,LocatorType locatorType,boolean scrollIntoView) {
		WebElement we = this.elementBy(locatorType, element);
		WebElement we1 = this.elementBy(locatorType, element2);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")", we);
		we.click();
	}

	public void scroll_and_Click(WebElement element,WebElement element2,boolean scrollIntoView) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")", element);
		waitUntilVisible(element2);
		element2.click();
	}

	public void scroll_and_Click(String element,String element2,LocatorType locatorType,LocatorType locatorType1,boolean scrollIntoView) {
		WebElement we = this.elementBy(locatorType, element);
		WebElement we1 = this.elementBy(locatorType1, element2);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")", we);
		we1.click();
	}


	public void navigateTo(String address) {
		driver.navigate().to(address);
	}

	public void navigateBack() {
		driver.navigate().back();
	}

	public void Fresh() {
		driver.navigate().refresh();
	}

	public void navigateForward() {
		driver.navigate().forward();
	}


	public void reloadPage(){
		driver.navigate().refresh();
	}


	// Custom Logs
	@Attachment
	public byte[] fetchBase64Screenshot(){
		return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
	}

	public void logScreenshot(String message) {
		String screenshot = Arrays.toString(fetchBase64Screenshot());
		LogUtil.logInfo(screenshot, message);
	}

	public void logScreenshot() {
		logScreenshot("Attached Screenshot");
	}


	public static void logInfo(String value) {
		LogUtil.logInfo(value);
	}


	// Action Methods with WebElement

	public String getTitle() {
		return driver.getTitle();
	}

	public String getURL() {
		return driver.getCurrentUrl();
	}

	public String getText(WebElement element) {
		return element.getText();
	}


	public String getText(String locator) { return this.getText(locator, LocatorType.xpath);

	}

	public String getText(String locator,LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);
		return we.getText();
	}

	public void switchToFrame(String locator){
		switchToFrame(locator, LocatorType.xpath);
	}

	public void switchToFrame(String locator, LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);
		switchToFrame(we);
	}

	public void switchToFrame(WebElement frameElement){
		driver.switchTo().frame(frameElement);
	}

	public void switchToFrame(int index){
		driver.switchTo().frame(index);
	}

	public void switchToParentFrame(){
		driver.switchTo().parentFrame();
	}

	public void switchToOutOfFrame(){
		driver.switchTo().defaultContent();
	}

	public void maximizeBrowser(){
		driver.manage().window().maximize();
	}

	public void minimizeBrowser(){
		driver.manage().window().minimize();
	}

	public void switchToTab(int tabIndex){
		Set<String> windowHandles=driver.getWindowHandles();
		List<String> windowHandlesList = new ArrayList<>(windowHandles);
		driver.switchTo().window(windowHandlesList.get(tabIndex));
	}

	public String getAttribute(String locator,String attributeName){
		return getAttribute(locator,attributeName,LocatorType.xpath);
	}

	public String getAttribute(String locator,String attributeName,LocatorType locatorType){
		WebElement element = elementBy(locatorType,locator);
		return element.getAttribute(attributeName);
	}


	public String getAttribute(WebElement element,String attributeName){
		return element.getAttribute(attributeName);
	}

	public boolean isDisplayed(String locator){
		return isDisplayed(locator,LocatorType.xpath);
	}

	public boolean isDisplayed(String locator,LocatorType locatorType){
		WebElement we = elementBy(locatorType,locator);
		return isDisplayed(we);
	}

	public boolean isDisplayed(WebElement element){
		try{
			explicitWait().until(ExpectedConditions.visibilityOf(element));
			return true;
		}catch (TimeoutException e){
			return false;
		}
	}

	public boolean isEnabled(String locator){
		return isEnabled(locator,LocatorType.xpath);
	}

	public boolean isEnabled(String locator,LocatorType locatorType) {
		WebElement element = elementBy(locatorType, locator);
		return element.isEnabled();
	}

	public boolean isEnabled(WebElement element){
		return element.isEnabled();
	}

	public boolean isEnabled(By by){
		WebElement element = driver.findElement(by);
		return element.isEnabled();
	}

	public boolean isSelected(String locator){
		return this.isSelected(locator,LocatorType.xpath);
	}

	public boolean isSelected(String locator,LocatorType locatorType){
		WebElement element = this.elementBy(locatorType,locator);
		return element.isSelected();
	}

	public boolean isSelected(WebElement element){
		return element.isSelected();
	}

	public boolean isSelected(String locator,WebElement element){
		return element.isSelected();
	}


}
