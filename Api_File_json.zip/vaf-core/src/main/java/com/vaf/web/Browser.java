package com.vaf.web;
import com.paulhammant.ngwebdriver.NgWebDriver;
import com.vaf.utils.LogUtil;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import com.vaf.enumerations.BrowserType;
import org.openqa.selenium.safari.SafariDriver;

/**
 * {@code Browser} handles actions for instantiating the Selenium WebDriver.
 * 

 */
public final class Browser {
	public Browser(){}

	public WebDriver driver;
	public NgWebDriver ngWebDriver = null;

	public WebDriver getChromeDriver(boolean headless) {
		ChromeOptions options = new ChromeOptions();
		if (headless) {
			options.addArguments("--headless=new");
		}
		return new ChromeDriver(options);
	}
	public WebDriver getFirefoxDriver(boolean headless) {
		FirefoxOptions options = new FirefoxOptions();
		if (headless) {
			options.addArguments("--headless");
		}
		return new FirefoxDriver(options);
	}
	public WebDriver getEdgeDriver(boolean headless) {
		EdgeOptions options = new EdgeOptions();
		if (headless) {
			options.addArguments("--headless=new");
		}
		return new EdgeDriver(options);
	}

	// DONT REMOVE
	//
	// Opera support was removed because opera uses chromium driver
	// Selenium uses chromium driver with hardcoded path to opera binary to run tests on it
	// This option might be supported in the future
	// https://chat.openai.com/?model=text-davinci-002-render-sha
	//
//	public WebDriver getOperaDriver(boolean headless) {
//		OperaOptions options = new OperaOptions();
//		if (headless) {
//			options.addArguments("--headless=new");
//		}
//		return new OperaDriver(options);
//	}
	public WebDriver getInternetExplorerDriver() {
		return new InternetExplorerDriver();
	}
	public WebDriver getSafariDriver() {
		return new SafariDriver();
	}
	public WebDriver getInstance(BrowserType browserType, boolean headless) {

		WebDriver driver;

		switch (browserType) {
			case CHROME:
				driver = getChromeDriver(headless);
				break;
			case FIREFOX:
				driver = getFirefoxDriver(headless);
				break;
			case EDGE:
				driver = getEdgeDriver(headless);
				break;
			case OPERA:
				LogUtil.logError("Opera browser is not support at the moment.");
				LogUtil.logError("Falling back to CHROME instead.");
				driver = getChromeDriver(headless);
				//driver = getOperaDriver(headless);
				break;
			case IE:
				if(headless) {
					LogUtil.logWarning("IE browser deos not support headless mode.");
				}
				driver = getInternetExplorerDriver();
				break;
			case SAFARI:
				if(headless) {
					LogUtil.logWarning("SAFARI browser deos not support headless mode.");
				}
				driver = getSafariDriver();
				break;
			default:
				throw new IllegalArgumentException("Invalid browser type: " + browserType);
		}

		this.ngWebDriver = new NgWebDriver((JavascriptExecutor) driver);
		return driver;
	}

}
