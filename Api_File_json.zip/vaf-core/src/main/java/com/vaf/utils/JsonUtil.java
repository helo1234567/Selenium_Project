package com.vaf.utils;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import io.restassured.config.Config;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.io.*;

public class JsonUtil {

    public static JSONObject loadJSON(String filePath) {
        JSONObject jsonObject = null;

        try {
            String jsonString = FileUtil.shared().readFile(filePath);
            jsonObject = new JSONObject(jsonString);

        } catch(URISyntaxException e){
            LogUtil.logError("Failed to load jason file.");
        }

        return jsonObject;
    }

    public static void saveJSON(JSONObject jsonObject, String filePath) {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(jsonObject.toString(4));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String buildAPIRequest(String endpoint, String method, JSONObject headers, JSONObject body) {
        JSONObject request = new JSONObject();
        request.put("endpoint", endpoint);
        request.put("method", method);

        if (headers != null) {
            request.put("headers", headers);
        }

        if (body != null) {
            request.put("body", body);
        }

        return request.toString();
    }

    public static boolean ValidJson(String jsonStr) {
        try {
            JsonElement jsonElement = JsonParser.parseString(jsonStr);
            return jsonElement.isJsonObject();
        } catch (Exception e) {
            return false;
        }
    }

    public static <T> T fetchValue(JSONObject jsonObject, String key, Class<T> returnType) {
        String[] keyParts = key.split("\\.");
        Object value = null;
        for (String part : keyParts) {
            if (value == null) {
                value = jsonObject.opt(part);
            } else if (value instanceof JSONObject) {
                value = ((JSONObject) value).opt(part);
            } else {
                return null;
            }
        }
        return returnType.cast(value);
    }

    public static Object fetchValue(JSONObject jsonObject, String key) {
        String[] keyParts = key.split("\\.");
        Object value = null;
        for (String part : keyParts) {
            if (value == null) {
                value = jsonObject.opt(part);
            } else if (value instanceof JSONObject) {
                value = ((JSONObject) value).opt(part);
            } else {
                return null;
            }
        }
        return value;
    }

}
