package com.spec;

import com.opencsv.exceptions.CsvValidationException;
import io.qameta.allure.Aggregator;
import io.qameta.allure.PluginConfiguration;
import io.qameta.allure.context.JacksonContext;
import io.qameta.allure.core.Configuration;
import io.qameta.allure.core.LaunchResults;
import io.qameta.allure.entity.TestResult;
import io.qameta.allure.Widget;
import io.qameta.allure.model.Status;
import com.opencsv.CSVReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class MyPlugin implements Aggregator, Widget {

    @Override
    public void aggregate(final Configuration configuration,
                          final List<LaunchResults> launches,
                          final Path outputDirectory) throws IOException {
        final JacksonContext jacksonContext = configuration
                .requireContext(JacksonContext.class);
        final Path dataFolder = Files.createDirectories(outputDirectory.resolve("data"));
        final Path dataFile = dataFolder.resolve("myplugindata.json");
        final Stream<TestResult> resultsStream = launches.stream()
                .flatMap(launch -> launch.getAllResults().stream());
        try (OutputStream os = Files.newOutputStream(dataFile)) {
            jacksonContext.getValue().writeValue(os, extractData(resultsStream.toString()));
        } catch (CsvValidationException e) {
            throw new RuntimeException(e);
        }
    }

    private Collection<Map<String, String>> extractData(final String csvFilePath) throws IOException, CsvValidationException {
        List<Map<String, String>> extractedData = new ArrayList<>();

        try (CSVReader csvReader = new CSVReader(new FileReader(csvFilePath))) {
            String[] header = csvReader.readNext(); // Read the header row

            String[] row;
            while ((row = csvReader.readNext()) != null) {
                Map<String, String> rowData = new HashMap<>();
                rowData.put("Sample Time", row[0]); // Assuming Sample Time is in the first column
                for (int i = 1; i < row.length; i++) {
                    rowData.put(header[i], row[i]);
                }
                extractedData.add(rowData);
            }
        }

        return extractedData;
    }

    @Override
    public Object getData(Configuration configuration, List<LaunchResults> launches) {
        Stream<TestResult> filteredResults = launches.stream().flatMap(launch -> launch.getAllResults().stream())
                .filter(result -> result.getStatus().equals(Status.FAILED));
        try {
            return extractData(filteredResults.toString());
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (CsvValidationException e) {
            throw new RuntimeException(e);
        }
    }



    @Override
    public String getName() {
        return "mywidget";
    }
}