package com.spec.performance;

import cucumber.api.java.en.When;
import io.gatling.app.Gatling;
import io.gatling.core.config.GatlingPropertiesBuilder;
import org.testng.annotations.Test;

public class Engine {
  public static String baseURI;
  public static int users;
  public static int rampUP;

  public static String endpoint;
  @Test
  @When("user navigates to {string} and put load of <{int}> users during <{int}> seconds on endpoint {string}")
  public void helo(String baseURi,int user,int rampup,String endPoint) {
    GatlingPropertiesBuilder props = new GatlingPropertiesBuilder()
      .resourcesDirectory(IDEPathHelper.mavenResourcesDirectory.toString())
      .resultsDirectory(IDEPathHelper.resultsDirectory.toString())
      .binariesDirectory(IDEPathHelper.mavenBinariesDirectory.toString());
       Gatling.fromMap(props.build());
    Engine.baseURI = baseURi;
    Engine.users = user;
    Engine.rampUP = rampup;
    Engine.endpoint = endPoint;


  }
}
