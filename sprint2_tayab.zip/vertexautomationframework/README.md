Vertex Automation Framework
Release: 0.1.x pre-alpha


Pre requisites
- JVM 17+
- Eclipse

Setup Instructions
- Open eclipse and got File > Import > Import As Maven Project