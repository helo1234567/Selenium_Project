package com.spec.gatlings;

import cucumber.api.java.en.When;

import java.io.IOException;

public class Stepdef {

    public static String Request;
    public static int Users;
    public static int RampUP;

    public static String Endpoint;

    @When("user sends {string} request for key {string} at endpoint {string} with <{int}> users during <{int}> seconds")
    public void Jmeter(String request,String key1,String endpoint,int users,int rampUP) throws IOException {

        Request = request;
        Users = users;
        RampUP = rampUP;
        Endpoint = endpoint;
        //Engine.executeLoadTest();

    }
}
