package com.spec.performance.Gatling_sample;

import io.gatling.javaapi.core.ChainBuilder;
import io.gatling.javaapi.core.ScenarioBuilder;
import io.gatling.javaapi.core.Simulation;
import io.gatling.javaapi.http.HttpProtocolBuilder;

import static io.gatling.javaapi.core.CoreDsl.*;
import static io.gatling.javaapi.http.HttpDsl.http;
import static io.gatling.javaapi.http.HttpDsl.status;

public class sample extends Simulation {

   // String request = Stepdef.Request;
    int user = 10;
    int rampUP = 10;
    String endpoint = "/maps/api/place/update/json";

    HttpProtocolBuilder httpProtocol =
            http.baseUrl("https://rahulshettyacademy.com")
                    .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .acceptLanguageHeader("en-US,en;q=0.5")
                    .acceptEncodingHeader("gzip, deflate")
                    .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:16.0) Gecko/20100101 Firefox/16.0");
    ChainBuilder search =
            exec(
                    http("Search")
                            .get(endpoint)
                            .check(status().is(200))
            );
    ScenarioBuilder users1 = scenario("users1").exec(search);
            {

        setUp(
                users1.injectOpen(rampUsers(user).during(rampUP))
        ).protocols(httpProtocol);

    }


}
