package com.vaf.api;


import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.vaf.utils.ConfigUtil;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class APIManager {

    public static HashMap<String, String> jsonToMap(String t) throws JSONException {

        HashMap<String, String> map = new HashMap<String, String>();
        JSONObject jObject = new JSONObject(t);
        Iterator<?> keys = jObject.keys();

        while( keys.hasNext() ){
            String key = (String)keys.next();
            String value = jObject.getString(key);
            map.put(key, value);

        }

        return map;
    }
    public boolean isValidJson(String jsonString) {
        try {
            new JSONObject(jsonString);
            return true;
        } catch (JSONException e) {
            return false;
        }
    }

    public static boolean ValidJson(String jsonStr) {
        try {
            JsonElement jsonElement = JsonParser.parseString(jsonStr);
            return jsonElement.isJsonObject();
        } catch (Exception e) {
            return false;
        }
    }
    public static String autoFillResponseValues(String oldRequestBody, String newRequestBody)
    {
        HashMap<String, String> body = jsonToMap(oldRequestBody);
        Pattern pattern = Pattern.compile("#\\{(.*?)\\}", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(newRequestBody);

        int index = 1;
        while (matcher.find()) {
            String keytoReplace = matcher.group(index);
            String valueToReplace = body.get(keytoReplace);

            newRequestBody=newRequestBody.replaceAll("#\\{"+keytoReplace+"\\}",""+valueToReplace);

        }
        return newRequestBody;
    }

    public Response PostRequest(String body, String header, String query, String endpoint, String method) {


        //RestAssured.baseURI = ConfigUtil.BASEURI("auth", ConfigUtil.ConfigType.APIConfig);
        String baseuri = ConfigUtil.BASEURI("auth", ConfigUtil.ConfigType.APIConfig);
        String ep = ConfigUtil.CONFIG_GET_STRING_COMP(endpoint, ConfigUtil.ConfigType.APIConfig);
        System.out.println("base: " + baseuri + ", endpoint: " + ep);
        Map<String, String> headers=jsonToMap(header);

        RequestSpecification request = RestAssured.given().baseUri(baseuri)
                .queryParam(query)
                .headers(headers)
                .body(body);

        Response response;



        if (method.equalsIgnoreCase("post")) {
            response = request.post(ep);
        } else if (method.equalsIgnoreCase("get")) {
            response = request.get(ep);
        }
        else if (method.equalsIgnoreCase("delete")) {
            response = request.delete(ep);
        }
        else if (method.equalsIgnoreCase("put")) {
            response = request.put(ep);
        }
        else {
            throw new IllegalArgumentException("Invalid request type: " + method);
        }

        return response;
    }

    public Response PostRequest(String modifiedJson, String endpoint, String method) {
        return null;
    }
}
