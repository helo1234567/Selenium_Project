package com.spec.performance;

import io.gatling.javaapi.core.*;
import static io.gatling.javaapi.core.CoreDsl.*;

// required for Gatling HTTP DSL
import io.gatling.javaapi.http.*;
import static io.gatling.javaapi.http.HttpDsl.*;
import io.gatling.core.Predef.*;
import io.gatling.http.Predef.*;
import scala.concurrent.duration.*;
// can be omitted if you don't use jdbcFeeder
import io.gatling.javaapi.jdbc.*;
import static io.gatling.javaapi.jdbc.JdbcDsl.*;

// used for specifying durations with a unit, eg Duration.ofMinutes(5)
import java.time.Duration;
public class MySimulation extends Simulation {

    final HttpProtocolBuilder httpProtocol = http
            .baseUrl("http://computer-database.gatling.io")
            .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .acceptLanguageHeader("en-US,en;q=0.5")
            .acceptEncodingHeader("gzip, deflate")
            .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:16.0) Gecko/20100101 Firefox/16.0");

    private final ScenarioBuilder scn = scenario("My Scenario")
            .exec(http("request_1")
                    .get("/page1"))
            .pause(1)
            .exec(http("request_2")
                    .get("/page2"))
            .pause(2)
            .exec(http("request_3")
                    .get("/page3"))
            .pause(3)
            .exec(http("request_4")
                    .get("/page4"));

    private final int numberOfUsers = 10;
    private final int rampDurationInSeconds = 10;

    public static void main(String[] args) {
        MySimulation simulation = new MySimulation();
        simulation.runSimulation();
    }

    public void runSimulation() {
        setUp(
                scn.injectOpen(rampUsers(numberOfUsers).during(rampDurationInSeconds))
        ).protocols(httpProtocol);
    }
}
