package com.spec.performance;
import io.gatling.javaapi.core.*;
import static io.gatling.javaapi.core.CoreDsl.*;

// required for Gatling HTTP DSL
import io.gatling.javaapi.http.*;
import static io.gatling.javaapi.http.HttpDsl.*;

// can be omitted if you don't use jdbcFeeder
import io.gatling.javaapi.jdbc.*;
import static io.gatling.javaapi.jdbc.JdbcDsl.*;

// used for specifying durations with a unit, eg Duration.ofMinutes(5)
import java.time.Duration;

public class Performanceee extends Simulation {

    private final HttpProtocolBuilder httpProtocol1 = http
            .baseUrl("https://computer-database.gatling.io")
            .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .acceptLanguageHeader("en-US,en;q=0.5")
            .acceptEncodingHeader("gzip, deflate")
            .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:16.0) Gecko/20100101 Firefox/16.0");

    private final HttpProtocolBuilder httpProtocol2 = http
            .baseUrl("https://computer-database.gatling.io")
            .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .acceptLanguageHeader("en-US,en;q=0.5")
            .acceptEncodingHeader("gzip, deflate")
            .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:16.0) Gecko/20100101 Firefox/16.0");

    private final ScenarioBuilder scn1 = scenario("scn1"); // Define your first scenario here
    private final ScenarioBuilder scn2 = scenario("scn2"); // Define your second scenario here

    public static void main(String[] args) {
        Performanceee simulation = new Performanceee();
        simulation.runSimulation();
    }

    public void runSimulation() {
        setUp(
                scn1.injectOpen(atOnceUsers(1))
                        .protocols(httpProtocol1),
                scn2.injectOpen(atOnceUsers(1))
                        .protocols(httpProtocol2)
        ).maxDuration(Duration.ofMinutes(1));
    }
}